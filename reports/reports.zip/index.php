<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
error_reporting(1);
include '../config.php';
session_start();
if($_SESSION['sid_digimedia_report']!=session_id())
{
//    $URL = "login.php";
//    header('Location: '.$URL);
    echo '<script type="text/javascript">
                             window.location.href = "login.php"
                    </script>';
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Welcome | Digital Ad Media</title>
<link href="../css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--[if lt IE 9]>
     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
     <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<style>
    .table_reportSearch{
        width: 60%;
        text-align: center;
        
    }
    .table_reportData{
        width: 80%;
        text-align: center;
      
    }
</style>
</head>
<body>
<div>
  <div class="container">
    <div class="row header">
      <div class="logo navbar-left">
        <h1><a href="index.php"><img src="../images/logo.jpg" width="287" height="88"></a></h1>
      </div>
      <div class="clearfix"></div>
    </div>
    <div class="row h_menu">
      <nav class="navbar navbar-default navbar-left" role="navigation"> 
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav">
                  <li class="active"><a href="#" class="scroll">Report</a></li>
<?php
                      if($_SESSION['digimedia_user_type'] == 'supadmin')
                      {
?>
                      <li><a href="upload_report.php">Import Data</a></li>
<?php
                      }
?>            
          </ul>
        </div>
      </nav>
    </div>
    <div class="clearfix"></div>
  </div>
</div>
<div class="main_bg">
</div>
<div class="main_btm">
  <div class="container">
    <div class="main row">
      <!--<div class="col-md-4 company_ad"></div>-->
      <!--<div class="col-md-8">-->
        <div class="contact-form">
          <h2>Impressions Monthly Report</h2>
<form name="form_report" method="post" action=''>
    <table align="center" class="table_reportSearch">
    <tr>
    <td>
        <select name="drp_month" size="1" id="drp_month">
         <option value='' selected>Select Month</option>
        <option value="01" <?php if($_POST['drp_month']=='01') { echo 'selected="selected"';}  ?> >January</option>
            <option value="02"  <?php if($_POST['drp_month']=='02') { echo 'selected="selected"';}  ?> >February</option>
            <option value="03"  <?php if($_POST['drp_month']=='03') { echo 'selected="selected"';}  ?> >March</option>
            <option value="04"  <?php if($_POST['drp_month']=='04') { echo 'selected="selected"';}  ?> >April</option>
            <option value="05"  <?php if($_POST['drp_month']=='05') { echo 'selected="selected"';}  ?> >May</option>
            <option value="06"  <?php if($_POST['drp_month']=='06') { echo 'selected="selected"';}  ?> >June</option>
            <option value="07"  <?php if($_POST['drp_month']=='07') { echo 'selected="selected"';}  ?> >July</option>
            <option value="08"  <?php if($_POST['drp_month']=='08') { echo 'selected="selected"';}  ?> >August</option>
            <option value="09"  <?php if($_POST['drp_month']=='09') { echo 'selected="selected"';}  ?> >September</option>
            <option value="10"  <?php if($_POST['drp_month']=='10') { echo 'selected="selected"';}  ?> >October</option>
            <option value="11"  <?php if($_POST['drp_month']=='11') { echo 'selected="selected"';}  ?> >November</option>
            <option value="12"  <?php if($_POST['drp_month']=='12') { echo 'selected="selected"';}  ?> >December</option>
        </select>
    </td>
    <td>
        <select name="drp_year" id='drp_year'>
            <option value='' selected>Select Year</option>
<?php
                $current_year = date('Y');
                for($loop_year ='2013'; $loop_year <= $current_year;$loop_year++)
                {
?>
                    <option value="<?= $loop_year?>" <?php if($_POST['drp_year'] == $loop_year) { echo 'selected="selected"'; }?> >
<?php                echo $loop_year;
?>
                    </option>
<?php
                }
?>
        </select>
     </td>
             <td><b>Group By :</b></td>
    <td>
    	<select name="drp_groupby" size="1" id="drp_groupby">
            <option value="country" selected >Country</option>
            <option value="Banner Size"  <?php if($_POST['drp_groupby']=='Banner Size') { echo 'selected="selected"';}  ?> >Banner Size</option>
        </select>
    </td>
        <td><input type="submit" name="sbt_search" value="Search" class="btn1"></td>
    </tr>
    </table> 
    <br>
      <table align='center' width='100%' border= '1px solid lightgrey' cellspacing='0' colspacing='0' class="table_reportData">
          <tr style="font-weight: bold;text-align: center;height: 35px;background-color: black;color:#FFFFFF ">
            <td>Sr No:</td>
            <td>Country</td>
<?php
                if($_POST['drp_groupby'] == 'Banner Size')
                {
                    $colspan = "3";
?>
                    <td>Banner Size</td>
<?php
                }
                else
                {
                    $colspan = "2";
                }
?>            
            <td>Impression</td>
            <td>CPM Rate</td>
            <td>Value</td>
         </tr>
         <?php

                 $sql_getImpressionsData = "SELECT date,country,type_size,SUM(total_imp) AS total_imp,cpm_rate,SUM(value)/1000 AS value "
                                            . "FROM impressions WHERE 1=1";
              
                    if($_POST['drp_month'])
                        $sql_getImpressionsData .= " AND MONTH(date)='".$_POST['drp_month']."'";
                    if($_POST['drp_year'])
                        $sql_getImpressionsData .= " AND YEAR(date)='".$_POST['drp_year']."'";
//           
                        $sql_getImpressionsData .=  " GROUP BY country ";
                if($_POST['drp_groupby'] == "Banner Size")
                        $sql_getImpressionsData .=  ",type_size";
                $sql_getImpressionsData .=  " ORDER BY country";
                $result_impressionsData = mysql_query($sql_getImpressionsData,$con);
                $count_records = mysql_num_rows($result_impressionsData);
                $int_loopId = 1;
                if($count_records)
                {
                    while($arr_impressionsData = mysql_fetch_array($result_impressionsData))
                    {
                    ?>
                       <tr style="text-align: center;height: 30px;">
                       <td><?php echo $int_loopId; ?></td>
                       <td><?php echo $arr_impressionsData['country']; ?></td>
<?php
                        if($_POST['drp_groupby'] == 'Banner Size')
                        {
?>
                            <td><?php echo $arr_impressionsData['type_size']; ?></td>
<?php
                        }
?>
                       <td align="right"><?php echo number_format($arr_impressionsData['total_imp']); ?></td>
                       <td><?php echo $arr_impressionsData['cpm_rate']; ?></td>
                       <td align="right"><?php echo number_format($arr_impressionsData['value'],2); ?></td>
                       </tr>
                       <?php
                       $int_totalImpressions += $arr_impressionsData['total_imp'];
                       $int_totalValue += $arr_impressionsData['value'];
                       $int_loopId++;
                    }
                 }
                 else
                 {
?>
                        <tr style="text-align: center;height: 30px;font-weight: bold;text-align: left;"><td colspan="4">Sorry no records found...!</td></tr>
<?php
                 }
                 ?>
                    <tr style="font-weight: bold;text-align: center;height: 35px;background-color: lightgrey;color:black; ">
                         <td colspan='<?=$colspan ?>' align='right'> Total:&nbsp;&nbsp; </td>
                        <td align="right"><?php echo number_format($int_totalImpressions); ?></td>
                        <td></td>
                        <td align="right"><?php echo number_format($int_totalValue,2); ?></td>
                    </tr>
      </table>    
   
    </form>
 </div>
      <!--</div>-->
      <div class="clearfix"></div>
    </div>
  </div>
</div>
<div class="footer_bg">
  <div class="container">
    <div class="row  footer">
      <div class="copy text-center">
        <p class="link"><span>&#169; All rights reserved | Digital Ad Media Limited</span>
<?php
if($_SESSION['sid_digimedia_report'] == session_id()){
?>
               | &nbsp;&nbsp; <a href="logout.php" ><b>Log out</b></a>
            
<?php
}
 ?>        
        
        </p>
      </div>
    </div>
  </div>
</div>
</body>
</html>
